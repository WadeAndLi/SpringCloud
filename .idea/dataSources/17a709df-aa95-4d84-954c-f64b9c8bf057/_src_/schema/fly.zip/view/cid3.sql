CREATE VIEW cid3 AS
  SELECT `fly`.`tb_category`.`parent_id` AS `parent_id`
  FROM `fly`.`tb_category`
  GROUP BY `fly`.`tb_category`.`parent_id`;
